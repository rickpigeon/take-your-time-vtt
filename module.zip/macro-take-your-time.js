// Macro "Take Your Time": mostra a tela de loading para todos os jogadores conectados.
// Precisa do módulo "Take Your Time (tela de loading)" ativo no mundo.
// Tipo do macro: Script. Mude só os valores abaixo; o que você apagar volta para o padrão.

const opcoes = {
  duracao: 3000,                 // em milissegundos (3000 = 3 segundos)
  texto: "TAKE YOUR TIME",
  subtitulo: "NOW LOADING",      // "" esconde

  // Imagem que atravessa a tela correndo (URL da internet ou caminho do Foundry, ex.: "worlds/meu-mundo/gato.webp")
  imagem: "https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/1f408-200d-2b1b.svg",
  imagemSilhueta: true,          // true = vira silhueta preta com contorno claro; false = cores originais
  espelharImagem: true,          // vira a imagem de lado (use se ela correr de costas)
  tamanhoImagem: 22,             // altura em % da tela

  // Imagem pequena que gira ao lado do subtítulo ("" esconde)
  imagemGiro: "https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/2b50.svg",
  giroSilhueta: true,            // true = fica toda na cor clara

  fundo: "",                     // imagem de fundo opcional (URL ou caminho do Foundry)
  opacidadeFundo: 0.35,

  som: "",                       // som opcional (URL ou caminho, ex.: "sounds/drums.wav")
  volume: 0.6,

  fonte: "Impact, 'Anton', 'Arial Black', sans-serif",
  cores: { principal: "#d7001b", escuro: "#0b0b0b", claro: "#ffffff" }
};

const api = game.modules.get("take-your-time")?.api;
if (!api) {
  ui.notifications.error("Ative o módulo \"Take Your Time (tela de loading)\" neste mundo.");
} else {
  api.broadcast(opcoes);
}

// Imagens padrão: Twemoji (CC BY 4.0, https://github.com/jdecked/twemoji).
