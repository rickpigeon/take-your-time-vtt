/**
 * Tela "Take Your Time": só DOM e CSS, sem nada do Foundry, para poder ser testada fora dele.
 * O visual fica em styles/take-your-time.css; aqui só se monta o HTML e se aplicam as opções.
 */

const TWEMOJI = "https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg";

/** Opções padrão. O macro pode mandar qualquer subconjunto delas. */
export const DEFAULTS = Object.freeze({
  duracao: 3000,
  texto: "TAKE YOUR TIME",
  subtitulo: "NOW LOADING",
  imagem: `${TWEMOJI}/1f408-200d-2b1b.svg`,
  imagemSilhueta: true,
  espelharImagem: true,
  tamanhoImagem: 22,
  imagemGiro: `${TWEMOJI}/2b50.svg`,
  giroSilhueta: true,
  fundo: "",
  opacidadeFundo: 0.35,
  som: "",
  volume: 0.6,
  fonte: "Impact, 'Anton', 'Arial Black', sans-serif",
  cores: Object.freeze({ principal: "#d7001b", escuro: "#0b0b0b", claro: "#ffffff" })
});

let current = null;

/**
 * Normaliza o que veio do macro (ou de outro cliente): os dados chegam pela rede,
 * então nada é usado sem checar tipo e limite.
 */
export function normalize(raw) {
  const o = raw && typeof raw === "object" ? raw : {};
  const num = (v, min, max, d) => (v !== "" && v !== null && Number.isFinite(Number(v)) ? Math.min(max, Math.max(min, Number(v))) : d);
  const str = (v, max, d) => (typeof v === "string" ? v.slice(0, max) : d);
  const bool = (v, d) => (typeof v === "boolean" ? v : d);
  const color = (v, d) => (typeof v === "string" && CSS.supports("color", v) ? v : d);
  const c = o.cores && typeof o.cores === "object" ? o.cores : {};
  return {
    duracao: num(o.duracao, 1000, 15000, DEFAULTS.duracao),
    texto: str(o.texto, 60, DEFAULTS.texto),
    subtitulo: str(o.subtitulo, 40, DEFAULTS.subtitulo),
    imagem: str(o.imagem, 2048, DEFAULTS.imagem),
    imagemSilhueta: bool(o.imagemSilhueta, DEFAULTS.imagemSilhueta),
    espelharImagem: bool(o.espelharImagem, DEFAULTS.espelharImagem),
    tamanhoImagem: num(o.tamanhoImagem, 5, 60, DEFAULTS.tamanhoImagem),
    imagemGiro: str(o.imagemGiro, 2048, DEFAULTS.imagemGiro),
    giroSilhueta: bool(o.giroSilhueta, DEFAULTS.giroSilhueta),
    fundo: str(o.fundo, 2048, DEFAULTS.fundo),
    opacidadeFundo: num(o.opacidadeFundo, 0, 1, DEFAULTS.opacidadeFundo),
    som: str(o.som, 2048, DEFAULTS.som),
    volume: num(o.volume, 0, 1, DEFAULTS.volume),
    fonte: str(o.fonte, 200, DEFAULTS.fonte),
    cores: {
      principal: color(c.principal, DEFAULTS.cores.principal),
      escuro: color(c.escuro, DEFAULTS.cores.escuro),
      claro: color(c.claro, DEFAULTS.cores.claro)
    }
  };
}

/** Número pseudoaleatório fixo por posição: todo mundo vê as letras com a mesma inclinação. */
function hash(n) {
  const x = Math.sin(n * 12.9898 + 78.233) * 43758.5453;
  return x - Math.floor(x);
}

function el(tag, className) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  return node;
}

function image(src, className) {
  const img = el("img", className);
  img.alt = "";
  img.decoding = "async";
  img.addEventListener("error", () => img.remove(), { once: true });
  img.src = src;
  return img;
}

/** Espera a imagem carregar, no máximo `ms`, para ela não aparecer no meio da animação. */
function preload(src, ms) {
  if (!src) return Promise.resolve();
  return new Promise((resolve) => {
    const img = new Image();
    const timer = setTimeout(resolve, ms);
    img.onload = img.onerror = () => {
      clearTimeout(timer);
      resolve();
    };
    img.src = src;
  });
}

function buildTitle(text) {
  const title = el("div", "tyt-title");
  const variants = ["a", "b", "c"];
  let i = 0;
  for (const word of text.split(/\s+/).filter(Boolean)) {
    const w = el("span", "tyt-word");
    for (const ch of word) {
      const s = el("span", `tyt-ch tyt-ch--${variants[Math.floor(hash(i) * 3)]}`);
      s.style.setProperty("--i", String(i));
      s.style.setProperty("--r", `${((hash(i + 101) - 0.5) * 18).toFixed(1)}deg`);
      s.style.setProperty("--s", (0.82 + hash(i + 202) * 0.36).toFixed(2));
      s.textContent = ch;
      w.append(s);
      i++;
    }
    title.append(w);
  }
  return title;
}

function build(o) {
  const root = el("div", "tyt-overlay");
  root.setAttribute("aria-hidden", "true");
  root.style.setProperty("--tyt-dur", `${o.duracao}ms`);
  root.style.setProperty("--tyt-red", o.cores.principal);
  root.style.setProperty("--tyt-dark", o.cores.escuro);
  root.style.setProperty("--tyt-light", o.cores.claro);
  root.style.setProperty("--tyt-img-h", `${o.tamanhoImagem}vh`);
  root.style.setProperty("--tyt-bg-op", String(o.opacidadeFundo));
  root.style.fontFamily = o.fonte;

  if (o.fundo) root.append(image(o.fundo, "tyt-bgimg"));
  root.append(el("div", "tyt-rays"), el("div", "tyt-dots"), el("div", "tyt-dots tyt-dots--b"));

  const band = el("div", "tyt-band");
  root.append(band, buildTitle(o.texto));

  if (o.imagem) {
    const runner = el("div", "tyt-runner");
    runner.classList.toggle("is-silhouette", o.imagemSilhueta);
    runner.classList.toggle("is-mirrored", o.espelharImagem);
    runner.append(image(o.imagem, "tyt-runner-img"));
    root.append(runner);
  }

  const loading = el("div", "tyt-loading");
  if (o.imagemGiro) {
    const spin = image(o.imagemGiro, "tyt-spin");
    spin.classList.toggle("is-silhouette", o.giroSilhueta);
    loading.append(spin);
  }
  if (o.subtitulo) {
    const label = el("span", "tyt-loading-text");
    label.textContent = o.subtitulo;
    const dots = el("span", "tyt-dots-text");
    for (let d = 0; d < 3; d++) {
      const dot = el("span", "tyt-dot");
      dot.style.setProperty("--d", String(d));
      dot.textContent = ".";
      dots.append(dot);
    }
    label.append(dots);
    loading.append(label);
  }
  root.append(loading, el("div", "tyt-flash"));
  return root;
}

/** Remove a tela que estiver aberta (útil para cancelar). */
export function stop() {
  if (!current) return;
  clearTimeout(current.timer);
  current.root.remove();
  current.resolve();
  current = null;
}

/**
 * Mostra a tela neste cliente. Resolve quando ela some.
 * @param {object} [options] Ver DEFAULTS.
 * @param {{preloadMs?: number}} [config]
 */
export async function play(options = {}, { preloadMs = 600 } = {}) {
  const o = normalize(options);
  await Promise.all([preload(o.imagem, preloadMs), preload(o.imagemGiro, preloadMs), preload(o.fundo, preloadMs)]);
  stop();
  const root = build(o);
  document.body.append(root);
  return new Promise((resolve) => {
    const entry = { root, resolve, timer: 0 };
    entry.timer = setTimeout(() => {
      if (current === entry) stop();
    }, o.duracao + 100);
    current = entry;
  });
}
