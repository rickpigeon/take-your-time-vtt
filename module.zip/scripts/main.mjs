import { DEFAULTS, normalize, play, stop } from "./overlay.mjs";

const MODULE_ID = "take-your-time";
const QUERY = `${MODULE_ID}.play`;

/** Mostra a tela neste cliente e toca o som, se houver. */
function show(options = {}) {
  const o = normalize(options);
  if (o.som) foundry.audio.AudioHelper.play({ src: o.som, volume: o.volume, autoplay: true, loop: false }, false);
  return play(o);
}

/**
 * Mostra a tela para todos os usuários conectados, inclusive quem disparou.
 * @param {object} [options] Ver DEFAULTS em overlay.mjs.
 */
async function broadcast(options = {}) {
  const data = normalize(options);
  const others = game.users.filter((u) => u.active && !u.isSelf);
  const pending = others.length
    ? foundry.documents.User.queryMany(others, QUERY, data, { timeout: data.duracao + 10000 })
    : Promise.resolve(new Map());
  show(data);
  const results = await pending;
  const failed = [...results].filter(([, r]) => r.status === "rejected").map(([u]) => u.name);
  if (failed.length) {
    ui.notifications.warn(`Take Your Time: a tela não chegou para ${failed.join(", ")}.`);
    console.warn(`${MODULE_ID} | falhou para`, failed, results);
  }
  return results;
}

Hooks.once("init", () => {
  CONFIG.queries[QUERY] = async (data) => {
    show(data);
    return true;
  };
  game.modules.get(MODULE_ID).api = { broadcast, play: show, stop, defaults: DEFAULTS };
});
