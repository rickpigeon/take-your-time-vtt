# Take Your Time (tela de loading)

Módulo para Foundry VTT v14. Um macro mostra uma tela de loading animada para todos os jogadores conectados, ao mesmo tempo, e ela some sozinha depois de alguns segundos (3 s por padrão).

## Instalar

No Foundry, vá em **Add-on Modules → Install Module** e cole no campo *Manifest URL*:

```
https://github.com/grax-arc/take-your-time/releases/latest/download/module.json
```

Depois ative o módulo no mundo, crie um macro do tipo **Script** e cole o conteúdo de [`macro-take-your-time.js`](macro-take-your-time.js). As opções (texto, imagens, cores, duração, som) ficam no topo do macro.

## Créditos

Imagens padrão: [Twemoji](https://github.com/jdecked/twemoji), licença CC BY 4.0.
